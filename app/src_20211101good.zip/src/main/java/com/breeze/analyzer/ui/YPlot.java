package com.breeze.analyzer.ui;

import com.breeze.analyzer.R;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Paint.Align;
 
import android.util.AttributeSet;
import android.util.Log;


public class YPlot extends BasicPlot {
	private Paint mTagLine;
	private Paint mTagFill;	

	private int mTriggerMode = 1;

	public YPlot(Context context, AttributeSet attrs) {
		super(context, attrs);

		updateScaler();

		xPaint2= new Paint(Paint.ANTI_ALIAS_FLAG);
		xPaint2.setColor(getContext().getResources().getColor( R.color.teal_700));//rpm
		xPaint2.setStyle(Paint.Style.FILL);
		xPaint2.setStrokeWidth(1);				
		xPaint2.setTextAlign( Align.RIGHT);	
		xPaint2.setTextSize(28); 		
		mPaintHint= new Paint(Paint.ANTI_ALIAS_FLAG);
		mPaintHint.setColor(getContext().getResources().getColor( R.color.teal_700));//fat
		mPaintHint.setStyle(Paint.Style.FILL);
		mPaintHint.setStrokeWidth(1);				
		mPaintHint.setTextAlign( Align.LEFT);	
		mPaintHint.setTextSkewX((float) -0.25);
		mPaintHint.setTextSize(36);  		
		mTagLine = new Paint(Paint.ANTI_ALIAS_FLAG);
		mTagLine.setColor(0xff00eeee);
		mTagLine.setStyle(Paint.Style.STROKE);
		mTagLine.setStrokeWidth(1);	
		mTagFill= new Paint(Paint.ANTI_ALIAS_FLAG);
		mTagFill.setColor(0xaa888888); 
		mTagFill.setStyle(Paint.Style.FILL);		
	}
	int findMaxYPos(short data[])
	{
		short nMax=0;
		int index = nCount*mSubSample/2;
		for (int i=index; i<data.length-nCount*mSubSample/2; i++) {
			if (data[i] > nMax){ nMax = data[i];index = i;}
		}
		mMaxY = nMax;
		return index;
	}
	short mMaxY = 0;

	public void setSeries(short data[]) {
		//buffer is read

		if (buffer == null) {
			buffer = new float[getSampleCounts()];
		}
		int start = 0;
		if (mTriggerMode == 1) {
			int nMax = findMaxYPos(data);
			start = nMax-nCount*mSubSample/2;
			if (start <0) start =0;
//			Log.d("YPlot", "start="+start +"center="+ nMax+ " max="+ mMaxY);
		}

		if (mSubSample > 1) {
			for (int i = 0; i < getSampleCounts(); i++) {
				long k = 0;
				if (data.length > (start+ (i+1) * mSubSample)) {
					for (int j = 0; j < mSubSample; j++) {
						k += data[start+i *mSubSample + j];
					}
					k /= mSubSample;
				}

				buffer[i] = k;
			}
		} else {
			for (int i = 0; i < nCount; i++)
				buffer[i] = data[start+i];
		}


		invalidate();
	}
	int mSampleRate=48000;
	public void setSampleRate(int sp) { mSampleRate = sp;}
	final int MAX_XSCALE_FACTOR = 6;
	int X_SCALE_FACTOR[] = {1, 2, 5, 10,20,50};
	int mCurXScaleFactor = 1;
	int mSubSample= 2;
	//48000/sec, take 10/div, one div = 1/4800 sec = 0.208ms ~12.5ms
	public int setXScale(int increase) {
		mCurXScaleFactor += increase;
		if(mCurXScaleFactor >= MAX_XSCALE_FACTOR)
			mCurXScaleFactor = MAX_XSCALE_FACTOR-1;
		else if (mCurXScaleFactor <0)
			mCurXScaleFactor = 0;
		mSubSample = X_SCALE_FACTOR[mCurXScaleFactor];
		updateScaler();
		invalidate();
		return X_SCALE_FACTOR[mCurXScaleFactor];
	}
	public int getXScale() {return X_SCALE_FACTOR[mCurXScaleFactor];}
	final int MAX_YSCALE_FACTOR = 12;
	int Y_SCALE_FACTOR[] = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000};
	int mCurYScaleFactor = 6;
	public int setYScale(int increase) {
		mCurYScaleFactor += increase;
		if(mCurYScaleFactor >= MAX_YSCALE_FACTOR)
			mCurYScaleFactor = MAX_YSCALE_FACTOR-1;
		else if (mCurYScaleFactor <0)
			mCurYScaleFactor = 0;
		updateScaler();
		invalidate();
		return Y_SCALE_FACTOR[mCurYScaleFactor];
	}
	public int getYScale() { return Y_SCALE_FACTOR[mCurYScaleFactor];}
	void updateScaler(){
		float yScale = Y_SCALE_FACTOR[mCurYScaleFactor];
		yLMax = 32767/yScale;
		yLMin = -yLMax;
		yL2P = (yPMax - yPMin) /(yLMax - yLMin); //negative YP-coordinate
	}

		@Override
	protected void drawTitle(Canvas canvas){
		String szTitle =getContext().getResources().getString(R.string.unit);
  
		canvas.drawText(szTitle, 0, yPMin/5, mPaintTitle);			
		String szRpm =getContext().getResources().getString(R.string.unit);
	
		canvas.drawText(szRpm, xPMin-5, (yPMin+yPMax)/2, xPaint2);
		
	}
	protected void drawPlot(Canvas canvas){
 	 
        float[] line = new float[4];
        float dx = (xPMax - xPMin)/nCount;
        line[0] = xPMin;        
        line[1] = getY(0)* yL2P + yPOrg;
        for(int i=1; i < nCount;i++)
        {
        	line[2] = line[0] + dx;
        	line[3] = getY(i)* yL2P + yPOrg;
            canvas.drawLines(line, mPaintLine);
            line[0] = line [2];
            line[1] = line[3];
        	
        }
		line[1] =mMaxY * yL2P + yPOrg;
		String value = Integer.toString((int)mMaxY);
		Path tag = new Path();
		float width = mPaintHint.measureText(value)+30;
		float y = line[1];
		tag.moveTo(xPMax+1, y);
		tag.lineTo(xPMax+15, y-20);
		tag.lineTo(xPMax+width, y-20);
		tag.lineTo(xPMax+width, y+20);
		tag.lineTo(xPMax+15, y+20);
		tag.close();
		canvas.drawPath(tag, mTagFill);
		canvas.drawPath(tag, mTagLine);
		canvas.drawText(value, xPMax+15, y+16, mPaintHint);

	}
}
